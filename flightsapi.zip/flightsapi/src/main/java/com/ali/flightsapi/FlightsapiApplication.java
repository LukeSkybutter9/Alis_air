package com.ali.flightsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightsapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightsapiApplication.class, args);
	}

}
