package com.ali.flightsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightsapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
